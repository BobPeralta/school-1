// adjust buttons on the side to page location after refresh
$(function () {
    var url = window.location.href;
    var array = url.split('#');
    var id = "#" + array[1];
    var id = id.match(/(\d+)/);
    var result = "button" + id[0];

    console.log(result);
    ColorButton(result, 'tabs');
});
$(document).on("click", function () {
    setTimeout(() => {
        var url = window.location.href;
        var array = url.split('#');
        var id = "#" + array[1];
        var id = id.match(/(\d+)/);
        var result = "button" + id[0];

        console.log(result);
        ColorButton(result, 'tabs');
    }, 1);
});

// on audio end, reset everything to normal
function func_track(audio, iconPAUSE, iconPLAY) {
    $(audio).on('ended', function() {
        console.log('finished');
        iconPLAY.style.display = "inline-block";
        iconPAUSE.style.display = "none";
    });
}