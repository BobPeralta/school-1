
$(document).ready(function () {
   // set scrolling correct on page loading
   let all = document.getElementsByClassName('bottom');
   for (i = 0; i < all.length; i++) {
      all[i].scrollTop = all[i].scrollHeight;
   }

   // get started button
   $('.start').click(function() {
      window.location.href='#scroll2'
   })
});

// set scrolling position after clicking on buttons
function AutoScroll(up, down) {
   up = document.getElementById(up);
   down = document.getElementById(down);

   if (up.scrollTop > 0) { up.scrollTop = 0; down.scrollTop = down.scrollHeight }
   else { up.scrollTop = up.scrollHeight; down.scrollTop = 0 };

   if (down.scrollTop > 0) { down.scrollTop = 0; up.scrollTop = up.scrollHeight }
   else { down.scrollTop = down.scrollHeight; up.scrollTop = 0 };
}