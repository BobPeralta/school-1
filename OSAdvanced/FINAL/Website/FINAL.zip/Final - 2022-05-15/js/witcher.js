/* Navigation button highlights */
function ColorButton(current, tabs) {
    elements = document.getElementsByClassName(tabs);
    for (var i = 0; i < elements.length; i++) {
        elements[i].style.backgroundColor = "transparent";
    }
    document.getElementById(current).style.backgroundColor = '#808080';
}

/* Character Menu items */
function character(person, other1, other2, text, other3, other4) {
    var geralt = 'geralt';
    var ciri = 'ciri';
    var wildhunt = 'wildhunt';

    document.getElementById(other1).style.transitionDuration = '1s';
    document.getElementById(other2).style.transitionDuration = '1s';

    document.getElementById(other3).style.display = 'none';
    document.getElementById(other4).style.display = 'none';
    document.getElementById(other1).style.width = '34%';
    document.getElementById(other2).style.width = '34%';

    if (document.getElementById(person).style.width == '250%') {
        document.getElementById(person).style.width = '34%';
        document.getElementById(text).style.display = 'none';
    }
    else {
        if (person.localeCompare(geralt) == 0) {
            document.getElementById(person).style.backgroundBlendMode = 'multiply';
        }
        if (person.localeCompare(ciri) == 0) {
            document.getElementById(person).style.backgroundBlendMode = 'multiply';
        }
        if (person.localeCompare(wildhunt) == 0) {
            document.getElementById(person).style.backgroundBlendMode = 'multiply';
        }
        document.getElementById(person).style.width = '250%';
        document.getElementById(text).style.display = 'block';
    }
}

/* map -tab, hide the text, show the map */
function mapShow(text, back) {
    if (document.getElementById(text).style.display == 'block') {
        document.getElementById(text).style.display = 'none';
        document.getElementById(back).style.width = '5%';
    }
    else {
        document.getElementById(text).style.display = 'block';
        document.getElementById(back).style.width = '30%';
    }
}

/* audio story telling pause / play button */
function audio_Play(audio, play, pause) {
    var track = document.getElementById(audio);
    var elements = document.getElementsByClassName('story_voice');

    let ClassPlay = document.getElementsByClassName('play');
    let ClassPause = document.getElementsByClassName('pause');

    if (track.paused) {
        for (var i = 0; i < elements.length; i++) {
            elements[i].pause();
            ClassPause[i].style.display = "none";
            ClassPlay[i].style.display = "inline-block";
        }
        track.play();
        document.getElementById(play).style.display = "none";
        document.getElementById(pause).style.display = "inline-block";
        func_track(track, document.getElementById(pause), document.getElementById(play));
    }
    else if (track.play) {
        track.pause();
        document.getElementById(play).style.display = "inline-block";
        document.getElementById(pause).style.display = "none";
    }
}

// adjust buttons on the side to page location after refresh
$(function () {
    var url = window.location.href;
    var array = url.split('#');
    var id = "#" + array[1];
    var id = id.match(/(\d+)/);
    var result = "button" + id[0];

    console.log(result);
    ColorButton(result, 'tabs');
});
$(document).on("click", function () {
    setTimeout(() => {
        var url = window.location.href;
        var array = url.split('#');
        var id = "#" + array[1];
        var id = id.match(/(\d+)/);
        var result = "button" + id[0];

        console.log(result);
        ColorButton(result, 'tabs');
    }, 1);
});

// on audio end, reset everything to normal
function func_track(audio, iconPAUSE, iconPLAY) {
    $(audio).on('ended', function() {
        console.log('finished');
        iconPLAY.style.display = "inline-block";
        iconPAUSE.style.display = "none";
    });
}

// better way of coloring nav buttons -- TESTING

// $(document).ready(function(){
//     $('.box').on('click', function(){
//         console.log(this.value);
//     });
// });