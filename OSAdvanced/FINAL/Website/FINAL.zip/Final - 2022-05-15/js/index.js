function OnClick(input) {
    if (input == 'nf') { window.location.href = '../index/nf.html'; }
    if (input == 'witcher') { window.location.href = '../index/witcher.html'; }
    if (input == 'bio') { window.location.href = '../index/bio.html'; }
    if (input == 'arduino') { window.location.href = '../index/arduino.html'; }
    if (input == 'contact') { window.location.href = '../index/contact.html'; }
}