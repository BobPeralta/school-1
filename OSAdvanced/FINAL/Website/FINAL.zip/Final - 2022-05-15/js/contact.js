function FormCheck() {
    var fname = document.getElementById("id_fname").value;
    var lname = document.getElementById("id_lname").value;
    var mail = document.getElementById("id_mail").value;
    var tel = document.getElementById("id_tel").value;
    var comment = document.getElementById("id_comment").value;

    var result = true;

    ColorError('id_fname_box', 'transparent');
    ColorError('id_lname_box', 'transparent');
    ColorError('id_tel_box', 'transparent');
    ColorError('id_mail_box', 'transparent');
    ColorError('id_comment_box', 'transparent');

    if (fname == "") {
        document.preventDefault;
        ColorError('id_fname_box', 'red');
        result = false;
    }
    if (lname == "") {
        document.preventDefault;
        ColorError('id_lname_box', 'red');
        result = false;
    }

    if (isNaN(tel) || tel.length < 9) {
        document.preventDefault;
        ColorError('id_tel_box', 'red');
        result = false;
    }

    if (!mail.includes("@", 1) | !mail.includes(".", 3) | mail.length < 5) {
        document.preventDefault;
        ColorError('id_mail_box', 'red');
        result = false;
    }

    if (comment == "") {
        document.preventDefault;
        ColorError('id_comment_box', 'red');
        result = false;
    }
    return result;
}

function ColorError(id, color) {
    if (color != 'red') {
        document.getElementById(id).style.border = '1px solid transparent';
    }
    else {
        document.getElementById(id).style.border = '1px solid red';
    }
}