$(window).scroll(function() {
    let a;
    if($(this).scrollTop() > 400) {
        a = document.getElementsByClassName('buttons');
        for(i=0;i<a.length;i++) {
            a[i].style.marginLeft = '92%';
        }
    }
    if($(this).scrollTop() < 400) {
        a = document.getElementsByClassName('buttons');
        for(i=0;i<a.length;i++) {
            a[i].style.marginLeft = '105%';
        }
    }
})

function GoTo(to) {
    if (to == 'linkedin') {
        window.open('https://www.linkedin.com/in/arno-halsberghe-15a8a5160/');
    }
    if (to == 'contact') {
        window.open('../index/contact.html');
    }
}