// audio controls
function play(input) {
    var iconPLAY = document.getElementById(input + '_play');
    var iconPAUSE = document.getElementById(input + '_pause');
    var audio = document.getElementById(input);
    
    if (audio.paused) {
        // if audio is paused, ask for vars, otherwise waste of resources
        let all = document.getElementsByTagName('audio');
        let ClassPlay = document.getElementsByClassName('iconPLAY');
        let ClassPause = document.getElementsByClassName('iconPAUSE');

        for(i=0;i<all.length;i++){
            all[i].pause();
            console.log('stopped id: ' + all[i].id);
            ClassPlay[i].style.display = "block";
            ClassPause[i].style.display = "none";
        }
        audio.play();
        console.log('playing id: ' + audio.id);
        func_track(audio, iconPAUSE, iconPLAY);
    }
    else {
        audio.pause();
        console.log('paused')
    };

    if (iconPLAY.style.display == "none") {
        iconPLAY.style.display = "block";
        iconPAUSE.style.display = "none";
    }
    else {
        iconPLAY.style.display = "none";
        iconPAUSE.style.display = "block";
    };
}

function func_track(audio, iconPAUSE, iconPLAY) {
    $(audio).on('ended', function() {
        console.log('finished id: ' + audio.id);
        iconPLAY.style.display = "block";
        iconPAUSE.style.display = "none";
    });
}